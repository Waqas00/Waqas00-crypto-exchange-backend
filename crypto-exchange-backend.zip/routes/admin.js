const express = require('express');
const router = express.Router();
// Add admin management routes here
module.exports = router;