const express = require('express');
const router = express.Router();
// Add login/register routes here
module.exports = router;